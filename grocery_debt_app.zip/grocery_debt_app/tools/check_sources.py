#!/usr/bin/env python3
"""Basic offline source/package check (not a Flutter analyzer)."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
required = [
    'pubspec.yaml', 'lib/main.dart', 'lib/models/customer.dart',
    'lib/models/debt_transaction.dart', 'lib/services/database_helper.dart',
    'lib/services/ledger_service.dart', 'lib/services/notification_service.dart',
    'lib/services/receipt_signing_service.dart',
    'lib/services/receipt_export_service.dart',
    'lib/screens/home_screen.dart', 'lib/screens/customer_details_screen.dart',
    'lib/screens/quick_transaction_dialog.dart',
    'lib/widgets/receipt_card.dart', 'lib/widgets/overdue_reminders_list.dart',
    'android/app/src/main/AndroidManifest.xml',
    'android/app/src/main/kotlin/com/example/smart_grocery_debt/MainActivity.kt',
]
missing = [name for name in required if not (root / name).is_file()]
for xml in root.glob('android/**/*.xml'):
    ET.parse(xml)
for dart in root.glob('lib/**/*.dart'):
    content = dart.read_text(encoding='utf-8')
    for rel in re.findall(r"^import ['\"](\.\.?/[^'\"]+)['\"];", content, re.M):
        path = (dart.parent / rel).resolve()
        if not path.exists():
            missing.append(f'{dart.relative_to(root)} -> {rel}')
if missing:
    print('Missing:', *missing, sep='\n')
    sys.exit(1)
print('All expected sources, local imports and XML parsed successfully.')
