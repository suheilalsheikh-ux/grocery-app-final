import 'dart:async';

import 'package:flutter/material.dart';

import '../models/customer.dart';
import '../services/database_helper.dart';
import '../theme/app_theme.dart';
import '../utils/money_format.dart';
import 'add_customer_dialog.dart';
import 'customer_details_screen.dart';
import 'quick_transaction_dialog.dart';

/// Fast, offline-first home screen. No database Future is created in build().
class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.shopName,
    this.shopPhone,
    this.database,
  });

  final String shopName;
  final String? shopPhone;
  final DatabaseHelper? database;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late final DatabaseHelper _database = widget.database ?? DatabaseHelper.instance;
  final SearchController _search = SearchController();
  Timer? _debounce;
  int _requestVersion = 0;
  bool _loading = true;
  String? _error;
  List<Customer> _customers = const [];
  DashboardSnapshot _summary = const DashboardSnapshot(
    totalOutstanding: 0,
    paymentsToday: 0,
  );

  @override
  void initState() {
    super.initState();
    _reload();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _requestVersion++;
    _search.dispose();
    super.dispose();
  }

  void _searchChanged(String query) {
    _debounce?.cancel();
    // Invalidate outstanding queries immediately, not after the debounce.
    ++_requestVersion;
    _debounce = Timer(const Duration(milliseconds: 180), _reload);
  }

  Future<void> _reload() async {
    final version = ++_requestVersion;
    final query = _search.text.trim();
    try {
      final results = await Future.wait<Object>([
        _database.getDashboardSnapshot(),
        _database.searchCustomers(query),
      ]);
      if (!mounted || version != _requestVersion) return;
      setState(() {
        _summary = results[0] as DashboardSnapshot;
        _customers = results[1] as List<Customer>;
        _loading = false;
        _error = null;
      });
    } catch (error) {
      if (!mounted || version != _requestVersion) return;
      setState(() {
        _loading = false;
        _error = 'تعذر قراءة بيانات البقالة. اسحب للتحديث.';
      });
    }
  }

  Future<void> _addCustomer() async {
    final created = await showDialog<Customer>(
      context: context,
      builder: (_) => AddCustomerDialog(database: _database),
    );
    if (created == null || !mounted) return;
    _showMessage('تمت إضافة ${created.name} بنجاح.');
    await _reload();
  }

  Future<void> _quick(Customer customer) async {
    final result = await showDialog<QuickTransactionResult>(
      context: context,
      builder: (_) => QuickTransactionDialog(
        customer: customer,
        shopName: widget.shopName,
      ),
    );
    if (result == null || !mounted) return;
    _showMessage(result.smsError == null
        ? 'تم حفظ العملية وتحديث الحساب.'
        : 'تم حفظ الدين، لكن تعذر إرسال SMS. لا تُعد تسجيل الدين.');
    await _reload();
  }

  Future<void> _openDetails(Customer customer) async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute(
        builder: (_) => CustomerDetailsScreen(
          customerId: customer.id!,
          shopName: widget.shopName,
          shopPhone: widget.shopPhone,
        ),
      ),
    );
    if (mounted) await _reload();
  }

  void _showMessage(String text) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('دفتر ديون البقالة',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            Text(widget.shopName, style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'تحديث الأرصدة',
            onPressed: _reload,
            icon: const Icon(Icons.refresh_outlined),
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 6, 16, 12),
              child: SearchBar(
                controller: _search,
                hintText: 'بحث سريع بالاسم أو رقم الهاتف',
                leading: const Icon(Icons.search),
                elevation: const WidgetStatePropertyAll(0),
                backgroundColor: const WidgetStatePropertyAll(Colors.white),
                padding: const WidgetStatePropertyAll(
                  EdgeInsets.symmetric(horizontal: 15)),
                onChanged: _searchChanged,
                trailing: [
                  if (_search.text.isNotEmpty)
                    IconButton(
                      tooltip: 'مسح البحث',
                      icon: const Icon(Icons.close),
                      onPressed: () {
                        _search.clear();
                        _searchChanged('');
                        setState(() {});
                      },
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Expanded(
                    child: _SummaryCard(
                      title: 'إجمالي ديون السوق بالريال',
                      amount: _summary.totalOutstanding,
                      icon: Icons.account_balance_wallet_outlined,
                      color: const Color(0xFFAF6B23),
                      background: const Color(0xFFFFF4E5),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _SummaryCard(
                      title: 'إجمالي المقبوضات اليوم',
                      amount: _summary.paymentsToday,
                      icon: Icons.payments_outlined,
                      color: AppTheme.positive,
                      background: const Color(0xFFE8F5ED),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  Text('الزبائن', style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w800)),
                  const SizedBox(width: 8),
                  Text('(${_customers.length})',
                      style: Theme.of(context).textTheme.bodyMedium),
                  const Spacer(),
                  if (_loading)
                    const SizedBox(width: 17, height: 17,
                        child: CircularProgressIndicator(strokeWidth: 2)),
                ],
              ),
            ),
            const SizedBox(height: 7),
            Expanded(
              child: RefreshIndicator(
                onRefresh: _reload,
                child: _error != null
                    ? ListView(children: [
                        const SizedBox(height: 56),
                        Icon(Icons.error_outline, size: 42,
                          color: Theme.of(context).colorScheme.error),
                        const SizedBox(height: 10),
                        Center(child: Text(_error!)),
                      ])
                    : ListView.builder(
                        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                        itemCount: _customers.isEmpty ? 1 : _customers.length,
                        itemBuilder: (context, index) {
                          if (_customers.isEmpty) {
                            return Padding(
                              padding: const EdgeInsets.only(top: 65),
                              child: Column(children: [
                                Icon(Icons.people_outline, size: 52,
                                  color: Theme.of(context).colorScheme.outline),
                                const SizedBox(height: 12),
                                Text(_loading ? 'جارٍ تحميل الزبائن...' :
                                  _search.text.isEmpty
                                      ? 'لا يوجد زبائن بعد. ابدأ بإضافة أول زبون.'
                                      : 'لا توجد نتائج لهذا البحث.'),
                              ]),
                            );
                          }
                          final customer = _customers[index];
                          return _CustomerCard(
                            key: ValueKey(customer.id),
                            customer: customer,
                            onQuick: () => _quick(customer),
                            onDetails: () => _openDetails(customer),
                          );
                        },
                      ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.large(
        tooltip: 'إضافة زبون جديد',
        onPressed: _addCustomer,
        child: const Icon(Icons.add, size: 38),
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.title,
    required this.amount,
    required this.icon,
    required this.color,
    required this.background,
  });

  final String title;
  final int amount;
  final IconData icon;
  final Color color;
  final Color background;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 146,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(22),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 9),
          Text(title, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
          const Spacer(),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerRight,
            child: Text(MoneyFormat.amount(amount),
              style: TextStyle(color: color, fontSize: 25,
                fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }
}

class _CustomerCard extends StatelessWidget {
  const _CustomerCard({
    super.key,
    required this.customer,
    required this.onQuick,
    required this.onDetails,
  });

  final Customer customer;
  final VoidCallback onQuick;
  final VoidCallback onDetails;

  @override
  Widget build(BuildContext context) {
    // SQL credit limit constraint means a new debt cannot exceed the cap.
    // Red means 'at/over cap', which also catches legacy data inconsistencies.
    final atOrOverLimit = customer.currentBalance > 0 &&
        customer.currentBalance >= customer.creditLimit;
    final accent = atOrOverLimit ? AppTheme.negative : AppTheme.positive;
    final bg = atOrOverLimit
        ? const Color(0xFFFFF0EE) : const Color(0xFFEDF8F1);
    final progress = customer.creditLimit <= 0
        ? 0.0
        : (customer.currentBalance / customer.creditLimit).clamp(0.0, 1.0).toDouble();
    return Card(
      color: bg,
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        onTap: onQuick,
        borderRadius: BorderRadius.circular(22),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            children: [
              Row(
                children: [
                  CircleAvatar(
                    backgroundColor: accent.withValues(alpha: 0.13),
                    foregroundColor: accent,
                    child: Text(customer.name.characters.first,
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(customer.name, maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w800,
                              fontSize: 16)),
                        Text(customer.phone, textDirection: TextDirection.ltr,
                            style: Theme.of(context).textTheme.bodySmall),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: onDetails,
                    tooltip: 'تفاصيل حساب ${customer.name}',
                    icon: const Icon(Icons.receipt_long_outlined),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Text('الرصيد: ${MoneyFormat.riyals(customer.currentBalance)}',
                      style: TextStyle(color: accent, fontWeight: FontWeight.w800)),
                  const Spacer(),
                  Text(atOrOverLimit ? 'بلغ السقف / تجاوزه' : 'ضمن السقف',
                      style: TextStyle(fontSize: 11, color: accent,
                        fontWeight: FontWeight.w700)),
                ],
              ),
              const SizedBox(height: 9),
              ClipRRect(
                borderRadius: BorderRadius.circular(5),
                child: LinearProgressIndicator(
                  value: progress,
                  minHeight: 5,
                  color: accent,
                  backgroundColor: accent.withValues(alpha: 0.13),
                ),
              ),
              const SizedBox(height: 6),
              Align(
                alignment: Alignment.centerRight,
                child: Text('سقف الدين: ${MoneyFormat.riyals(customer.creditLimit)}',
                    style: Theme.of(context).textTheme.bodySmall),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
