import 'dart:convert';

import 'package:crypto/crypto.dart' show sha256;
import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../models/debt_transaction.dart';

/// Transport object for one digitally signed QR receipt.
class ReceiptSignature {
  final String qrPayload;
  final String publicKeyBase64;
  final String publicKeyFingerprint;

  const ReceiptSignature({
    required this.qrPayload,
    required this.publicKeyBase64,
    required this.publicKeyFingerprint,
  });
}

/// Ed25519 receipts can be verified offline by another device *only* if that
/// device has an independently authenticated merchant public key.
///
/// The private key is stored with Android Keystore-backed secure storage.
/// Export/back up signing identity responsibly before device migration; losing
/// the private key makes issuing receipts under the old identity impossible.
class ReceiptSigningService {
  ReceiptSigningService._();

  static final ReceiptSigningService instance = ReceiptSigningService._();

  static const String _privateKeyStorageName = 'receipt_ed25519_private_v1';
  static const String _publicKeyStorageName = 'receipt_ed25519_public_v1';

  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  final Ed25519 _algorithm = Ed25519();
  Future<SimpleKeyPairData>? _keyPairFuture;

  Future<SimpleKeyPairData> _keyPair() async {
    final existing = _keyPairFuture;
    if (existing != null) return existing;

    final pending = _loadOrGenerateKeyPair();
    _keyPairFuture = pending;
    try {
      return await pending;
    } catch (_) {
      _keyPairFuture = null;
      rethrow;
    }
  }

  Future<SimpleKeyPairData> _loadOrGenerateKeyPair() async {
    final privateText = await _storage.read(key: _privateKeyStorageName);
    final publicText = await _storage.read(key: _publicKeyStorageName);

    if (privateText == null && publicText == null) {
      final generated = await _algorithm.newKeyPair();
      final data = await generated.extract();
      final publicKey = await generated.extractPublicKey();
      // Secure storage handles encryption at rest; never store the secret in SQLite.
      await _storage.write(
        key: _publicKeyStorageName,
        value: base64UrlEncode(publicKey.bytes),
      );
      await _storage.write(
        key: _privateKeyStorageName,
        value: base64UrlEncode(data.bytes),
      );
      return data;
    }

    // No silent key regeneration: old receipts would otherwise lose identity.
    if (privateText == null || publicText == null) {
      throw StateError('بيانات مفتاح توقيع الإيصالات غير مكتملة.');
    }

    try {
      final privateBytes = base64Url.decode(privateText);
      final publicBytes = base64Url.decode(publicText);
      if (privateBytes.length != 32 || publicBytes.length != 32) {
        throw const FormatException('Invalid Ed25519 key length');
      }
      return SimpleKeyPairData(
        privateBytes,
        publicKey: SimplePublicKey(
          publicBytes,
          type: KeyPairType.ed25519,
        ),
        type: KeyPairType.ed25519,
      );
    } on FormatException catch (error) {
      throw StateError('تعذر قراءة مفتاح التوقيع: $error');
    }
  }

  Future<String> getPublicKeyBase64() async {
    final publicKey = await (await _keyPair()).extractPublicKey();
    return base64UrlEncode(publicKey.bytes);
  }

  Future<String> getPublicKeyFingerprint() async {
    final publicKey = await (await _keyPair()).extractPublicKey();
    return sha256.convert(publicKey.bytes).toString().substring(0, 16);
  }

  /// Signs all receipt fields, including the original SHA-256 transaction hash.
  Future<ReceiptSignature> signReceipt({
    required String storeName,
    required String customerName,
    required String currencyCode,
    required int unitsPerMajor,
    required DebtTransaction transaction,
    required int balanceAfter,
  }) async {
    if (!transaction.hasValidHash || transaction.id == null) {
      throw StateError('لا يمكن توقيع معاملة ذات بصمة غير صحيحة.');
    }
    if (balanceAfter < 0) {
      throw ArgumentError.value(balanceAfter, 'balanceAfter');
    }

    // Fixed key order ensures identical serialization for sign and verify.
    final payload = <String, Object?>{
      'v': 1,
      'shop': storeName,
      'cid': transaction.customerId,
      'customer': customerName,
      'tx': transaction.id,
      'type': transaction.type.databaseValue,
      'amount': transaction.amount,
      'items': transaction.purchases,
      'at': transaction.createdAt.toUtc().toIso8601String(),
      'balance': balanceAfter,
      'currency': currencyCode,
      'unit': unitsPerMajor,
      'prev': transaction.previousHash,
      'hash': transaction.recordHash,
    };

    final keyPair = await _keyPair();
    final signature = await _algorithm.sign(
      utf8.encode(jsonEncode(payload)),
      keyPair: keyPair,
    );
    final publicKey = await keyPair.extractPublicKey();
    final publicText = base64UrlEncode(publicKey.bytes);
    final signedQr = jsonEncode(<String, Object?>{
      'alg': 'Ed25519',
      'receipt': payload,
      'pub': publicText,
      'sig': base64UrlEncode(signature.bytes),
    });

    return ReceiptSignature(
      qrPayload: signedQr,
      publicKeyBase64: publicText,
      publicKeyFingerprint: sha256
          .convert(publicKey.bytes)
          .toString()
          .substring(0, 16),
    );
  }

  /// Offline verifier: trustedPublicKeyBase64 must come from an independent
  /// trusted source (e.g. a key distributed by the merchant), NOT from this QR.
  /// It validates Ed25519 signature AND recalculates the DB SHA-256 record hash.
  static Future<bool> verifyQrPayload({
    required String qrPayload,
    required String trustedPublicKeyBase64,
  }) async {
    try {
      final envelope = jsonDecode(qrPayload);
      if (envelope is! Map<String, dynamic>) return false;
      if (envelope['alg'] != 'Ed25519') return false;

      final embeddedPublicKey = envelope['pub'];
      final signatureText = envelope['sig'];
      final payload = envelope['receipt'];
      if (embeddedPublicKey is! String ||
          signatureText is! String ||
          payload is! Map<String, dynamic> ||
          embeddedPublicKey != trustedPublicKeyBase64) {
        return false;
      }
      if (payload['v'] != 1 || payload['shop'] is! String ||
          payload['customer'] is! String ||
          payload['currency'] is! String ||
          payload['unit'] is! int ||
          (payload['unit'] as int) <= 0 ||
          payload['balance'] is! int ||
          (payload['balance'] as int) < 0 ||
          payload['cid'] is! int ||
          payload['tx'] is! int ||
          payload['amount'] is! int ||
          (payload['amount'] as int) <= 0 ||
          payload['items'] is! String ||
          payload['at'] is! String ||
          payload['prev'] is! String ||
          payload['hash'] is! String ||
          payload['type'] is! String) {
        return false;
      }

      final publicBytes = base64Url.decode(embeddedPublicKey);
      final signatureBytes = base64Url.decode(signatureText);
      if (publicBytes.length != 32 || signatureBytes.length != 64) {
        return false;
      }
      final publicKey = SimplePublicKey(
        publicBytes,
        type: KeyPairType.ed25519,
      );
      final verified = await Ed25519().verify(
        utf8.encode(jsonEncode(payload)),
        signature: Signature(signatureBytes, publicKey: publicKey),
      );
      if (!verified) return false;

      final type = DebtTransactionType.fromDatabaseValue(
        payload['type'] as String,
      );
      final expectedHash = DebtTransaction.calculateHash(
        id: payload['tx'] as int,
        customerId: payload['cid'] as int,
        type: type,
        amount: payload['amount'] as int,
        purchases: payload['items'] as String,
        createdAt: DateTime.parse(payload['at'] as String),
        previousHash: payload['prev'] as String,
      );
      return expectedHash == payload['hash'];
    } catch (_) {
      return false;
    }
  }
}
