import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/customer.dart';
import '../models/debt_transaction.dart';

class VerifiedCustomerLedger {
  final Customer customer;
  final List<DebtTransaction> transactions;

  const VerifiedCustomerLedger({required this.customer, required this.transactions});
}

/// Two figures read from the same SQLite snapshot for the home dashboard.
class DashboardSnapshot {
  final int totalOutstanding;
  final int paymentsToday;

  const DashboardSnapshot({
    required this.totalOutstanding,
    required this.paymentsToday,
  });
}

class DatabaseHelper {
  DatabaseHelper._();

  static final DatabaseHelper instance = DatabaseHelper._();

  static const String _databaseName = 'smart_grocery_debt.db';
  static const int _databaseVersion = 1;
  static const String _customersTable = 'customers';
  static const String _transactionsTable = 'debt_transactions';

  Database? _database;
  Future<Database>? _openingDatabase;

  Future<Database> _getDatabase() async {
    final existing = _database;
    if (existing != null && existing.isOpen) return existing;

    final inProgress = _openingDatabase;
    if (inProgress != null) return inProgress;

    final opening = _openDatabase();
    _openingDatabase = opening;
    try {
      final database = await opening;
      _database = database;
      return database;
    } finally {
      _openingDatabase = null;
    }
  }

  Future<Database> _openDatabase() async {
    final databaseDirectory = await getDatabasesPath();
    final databasePath = p.join(databaseDirectory, _databaseName);

    return openDatabase(
      databasePath,
      version: _databaseVersion,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: _createSchema,
    );
  }

  Future<void> _createSchema(Database db, int version) async {
    await db.execute('''
      CREATE TABLE $_customersTable (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL CHECK (length(trim(name)) > 0),
        phone TEXT NOT NULL CHECK (length(trim(phone)) > 0),
        credit_limit INTEGER NOT NULL DEFAULT 0
          CHECK (credit_limit >= 0),
        current_balance INTEGER NOT NULL DEFAULT 0
          CHECK (current_balance >= 0 AND current_balance <= credit_limit)
      )
    ''');

    await db.execute('''
      CREATE TABLE $_transactionsTable (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        type TEXT NOT NULL CHECK (type IN ('debt', 'payment')),
        amount INTEGER NOT NULL CHECK (amount > 0),
        purchases TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        previous_hash TEXT NOT NULL,
        record_hash TEXT NOT NULL CHECK (length(record_hash) = 64),
        FOREIGN KEY (customer_id)
          REFERENCES $_customersTable(id) ON DELETE RESTRICT,
        CHECK (
          (type = 'debt' AND length(trim(purchases)) > 0)
          OR (type = 'payment' AND purchases = '')
        )
      )
    ''');

    await db.execute('''
      CREATE INDEX idx_customers_name
      ON $_customersTable(name)
    ''');

    await db.execute('''
      CREATE INDEX idx_customers_phone
      ON $_customersTable(phone)
    ''');

    await db.execute('''
      CREATE INDEX idx_transactions_customer_id_id
      ON $_transactionsTable(customer_id, id)
    ''');

    // The stored ledger is append-only through ordinary SQLite operations.
    await db.execute('''
      CREATE TRIGGER trg_transactions_no_update
      BEFORE UPDATE ON $_transactionsTable
      BEGIN
        SELECT RAISE(ABORT, 'Transactions cannot be edited');
      END
    ''');

    await db.execute('''
      CREATE TRIGGER trg_transactions_no_delete
      BEFORE DELETE ON $_transactionsTable
      BEGIN
        SELECT RAISE(ABORT, 'Transactions cannot be deleted');
      END
    ''');

    await db.execute('''
      CREATE TRIGGER trg_transactions_chain
      BEFORE INSERT ON $_transactionsTable
      WHEN NEW.previous_hash != COALESCE(
        (
          SELECT record_hash
          FROM $_transactionsTable
          WHERE customer_id = NEW.customer_id
          ORDER BY id DESC
          LIMIT 1
        ),
        '${DebtTransaction.genesisHash}'
      )
      BEGIN
        SELECT RAISE(ABORT, 'Invalid previous transaction hash');
      END
    ''');

    // Each INSERT updates the customer balance atomically.
    await db.execute('''
      CREATE TRIGGER trg_transactions_update_balance
      AFTER INSERT ON $_transactionsTable
      BEGIN
        UPDATE $_customersTable
        SET current_balance = current_balance +
          CASE
            WHEN NEW.type = 'debt' THEN NEW.amount
            ELSE -NEW.amount
          END
        WHERE id = NEW.customer_id;
      END
    ''');

    // A manual balance change is rejected unless it matches the whole ledger.
    await db.execute('''
      CREATE TRIGGER trg_customers_balance_integrity
      BEFORE UPDATE OF current_balance ON $_customersTable
      WHEN NEW.current_balance != COALESCE(
        (
          SELECT SUM(
            CASE WHEN type = 'debt' THEN amount ELSE -amount END
          )
          FROM $_transactionsTable
          WHERE customer_id = OLD.id
        ),
        0
      )
      BEGIN
        SELECT RAISE(ABORT, 'Balance does not match transaction ledger');
      END
    ''');
  }

  void _validateCustomerFields(Customer customer) {
    if (customer.name.trim().isEmpty) {
      throw ArgumentError('اسم الزبون مطلوب.');
    }
    if (customer.phone.trim().isEmpty) {
      throw ArgumentError('رقم هاتف الزبون مطلوب.');
    }
    if (customer.creditLimit < 0) {
      throw ArgumentError('سقف الدين لا يمكن أن يكون سالباً.');
    }
  }

  Future<Customer> createCustomer(Customer customer) async {
    _validateCustomerFields(customer);
    if (customer.id != null) {
      throw ArgumentError('لا ترسل معرفاً عند إنشاء زبون جديد.');
    }
    if (customer.currentBalance != 0) {
      throw ArgumentError('رصيد الزبون الجديد يجب أن يكون صفراً.');
    }

    final database = await _getDatabase();
    final customerData = <String, Object?>{
      'name': customer.name.trim(),
      'phone': customer.phone.trim(),
      'credit_limit': customer.creditLimit,
      'current_balance': 0,
    };
    final id = await database.insert(_customersTable, customerData);
    return Customer(
      id: id,
      name: customerData['name']! as String,
      phone: customerData['phone']! as String,
      creditLimit: customer.creditLimit,
    );
  }

  Future<Customer?> getCustomer(int customerId) async {
    final database = await _getDatabase();
    final rows = await database.query(
      _customersTable,
      where: 'id = ?',
      whereArgs: <Object>[customerId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return Customer.fromMap(rows.first);
  }

  Future<List<Customer>> getAllCustomers() async {
    final database = await _getDatabase();
    final rows = await database.query(_customersTable, orderBy: 'name COLLATE NOCASE ASC');
    return rows.map(Customer.fromMap).toList(growable: false);
  }

  Future<List<Customer>> searchCustomers(String text) async {
    final database = await _getDatabase();
    final query = text.trim();
    if (query.isEmpty) return getAllCustomers();

    // Escape LIKE wildcard characters to treat search text literally.
    final escaped = query
        .replaceAll('\\', '\\\\')
        .replaceAll('%', '\\%')
        .replaceAll('_', '\\_');
    final pattern = '%$escaped%';
    final rows = await database.query(
      _customersTable,
      where: r"name LIKE ? ESCAPE '\' OR phone LIKE ? ESCAPE '\'",
      whereArgs: <Object>[pattern, pattern],
      orderBy: 'name COLLATE NOCASE ASC',
    );
    return rows.map(Customer.fromMap).toList(growable: false);
  }

  Future<Customer> updateCustomer(Customer customer) async {
    _validateCustomerFields(customer);
    final customerId = customer.id;
    if (customerId == null) {
      throw ArgumentError('معرف الزبون مطلوب للتعديل.');
    }

    final database = await _getDatabase();
    return database.transaction((transaction) async {
      final oldCustomer = await _customerInTransaction(transaction, customerId);
      if (oldCustomer == null) {
        throw StateError('الزبون غير موجود.');
      }
      if (!await _verifyLedgerInTransaction(transaction, oldCustomer)) {
        throw StateError('فشل التحقق من سلامة سجلات الزبون.');
      }
      if (customer.creditLimit < oldCustomer.currentBalance) {
        throw StateError('سقف الدين الجديد أقل من الرصيد المستحق.');
      }

      await transaction.update(
        _customersTable,
        <String, Object?>{
          'name': customer.name.trim(),
          'phone': customer.phone.trim(),
          'credit_limit': customer.creditLimit,
        },
        where: 'id = ?',
        whereArgs: <Object>[customerId],
      );

      return Customer(
        id: customerId,
        name: customer.name.trim(),
        phone: customer.phone.trim(),
        creditLimit: customer.creditLimit,
        currentBalance: oldCustomer.currentBalance,
      );
    });
  }

  Future<void> deleteCustomer(int customerId) async {
    final database = await _getDatabase();
    await database.transaction((transaction) async {
      final customer = await _customerInTransaction(transaction, customerId);
      if (customer == null) throw StateError('الزبون غير موجود.');
      if (!await _verifyLedgerInTransaction(transaction, customer)) {
        throw StateError('فشل التحقق من سلامة سجلات الزبون.');
      }
      final entries = Sqflite.firstIntValue(await transaction.rawQuery(
        'SELECT COUNT(*) FROM $_transactionsTable WHERE customer_id = ?',
        <Object>[customerId],
      ));
      if ((entries ?? 0) > 0) {
        throw StateError('لا يمكن حذف زبون لديه سجل معاملات.');
      }
      await transaction.delete(
        _customersTable,
        where: 'id = ?',
        whereArgs: <Object>[customerId],
      );
    });
  }

  Future<DebtTransaction> addDebt({
    required int customerId,
    required int amount,
    required String purchases,
  }) {
    return addTransaction(
      customerId: customerId,
      type: DebtTransactionType.debt,
      amount: amount,
      purchases: purchases,
    );
  }

  Future<DebtTransaction> registerPayment({
    required int customerId,
    required int amount,
  }) {
    return addTransaction(
      customerId: customerId,
      type: DebtTransactionType.payment,
      amount: amount,
    );
  }

  Future<DebtTransaction> addTransaction({
    required int customerId,
    required DebtTransactionType type,
    required int amount,
    String purchases = '',
  }) async {
    if (customerId <= 0) throw ArgumentError('معرف الزبون غير صالح.');
    if (amount <= 0) throw ArgumentError('مبلغ المعاملة يجب أن يكون أكبر من صفر.');

    final cleanPurchases = purchases.trim();
    if (type == DebtTransactionType.debt && cleanPurchases.isEmpty) {
      throw ArgumentError('يجب توضيح المشتريات عند تسجيل دين.');
    }
    if (type == DebtTransactionType.payment && cleanPurchases.isNotEmpty) {
      throw ArgumentError('حقل المشتريات مخصص لمعاملات الدين فقط.');
    }

    final database = await _getDatabase();
    return database.transaction((transaction) async {
      final customer = await _customerInTransaction(transaction, customerId);
      if (customer == null) throw StateError('الزبون غير موجود.');

      if (!await _verifyLedgerInTransaction(transaction, customer)) {
        throw StateError(
          'سجل المعاملات أو الرصيد غير متطابق؛ تم إيقاف العملية لحماية الحساب.',
        );
      }

      if (type == DebtTransactionType.debt) {
        if (amount > customer.creditLimit - customer.currentBalance) {
          throw StateError('قيمة الدين تتجاوز سقف الدين المتاح للزبون.');
        }
      } else {
        if (amount > customer.currentBalance) {
          throw StateError('قيمة السداد تتجاوز الرصيد المستحق.');
        }
      }

      final latestRows = await transaction.query(
        _transactionsTable,
        columns: <String>['record_hash'],
        where: 'customer_id = ?',
        whereArgs: <Object>[customerId],
        orderBy: 'id DESC',
        limit: 1,
      );
      final previousHash = latestRows.isEmpty
          ? DebtTransaction.genesisHash
          : latestRows.first['record_hash']! as String;

      final idRows = await transaction.rawQuery(
        'SELECT COALESCE(MAX(id), 0) + 1 AS next_id FROM $_transactionsTable',
      );
      final nextId = idRows.first['next_id']! as int;

      final entry = DebtTransaction.create(
        id: nextId,
        customerId: customerId,
        type: type,
        amount: amount,
        purchases: type == DebtTransactionType.debt ? cleanPurchases : '',
        createdAt: DateTime.now().toUtc(),
        previousHash: previousHash,
      );

      // The INSERT trigger updates current_balance in the same SQL transaction.
      await transaction.insert(_transactionsTable, entry.toMap());

      final updatedCustomer = await _customerInTransaction(transaction, customerId);
      if (updatedCustomer == null ||
          !await _verifyLedgerInTransaction(transaction, updatedCustomer)) {
        throw StateError('فشل التحقق من المعاملة الجديدة؛ تم إلغاء العملية.');
      }
      return entry;
    });
  }

  Future<DebtTransaction?> getTransactionById(int transactionId) async {
    final database = await _getDatabase();
    final rows = await database.query(
      _transactionsTable,
      where: 'id = ?',
      whereArgs: <Object>[transactionId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return DebtTransaction.fromMap(rows.first);
  }

  Future<List<DebtTransaction>> getCustomerTransactions(int customerId) async {
    final database = await _getDatabase();
    final rows = await database.query(
      _transactionsTable,
      where: 'customer_id = ?',
      whereArgs: <Object>[customerId],
      orderBy: 'id DESC',
    );
    return rows.map(DebtTransaction.fromMap).toList(growable: false);
  }

  /// Consistent SQLite snapshot with integrity verification.
  Future<VerifiedCustomerLedger> getVerifiedCustomerLedger(int customerId) async {
    final database = await _getDatabase();
    return database.transaction((transaction) async {
      final customer = await _customerInTransaction(transaction, customerId);
      if (customer == null) throw StateError('الزبون غير موجود.');
      if (!await _verifyLedgerInTransaction(transaction, customer)) {
        throw StateError('فشل التحقق من سلامة السجل أو الرصيد.');
      }
      final rows = await transaction.query(
        _transactionsTable,
        where: 'customer_id = ?',
        whereArgs: <Object>[customerId],
        orderBy: 'id ASC',
      );
      return VerifiedCustomerLedger(
        customer: customer,
        transactions: List<DebtTransaction>.unmodifiable(
          rows.map(DebtTransaction.fromMap),
        ),
      );
    });
  }

  /// Today's payments use the DEVICE's local calendar date, converted to UTC.
  /// Both aggregate values are read in one transaction for consistency.
  Future<DashboardSnapshot> getDashboardSnapshot({DateTime? now}) async {
    final local = (now ?? DateTime.now()).toLocal();
    final start = DateTime(local.year, local.month, local.day).toUtc();
    final end = DateTime(local.year, local.month, local.day + 1).toUtc();
    final db = await _getDatabase();
    return db.transaction((txn) async {
      final totalRows = await txn.rawQuery('''
        SELECT COALESCE(SUM(current_balance), 0) AS total
        FROM $_customersTable
      ''');
      final todayRows = await txn.rawQuery('''
        SELECT COALESCE(SUM(amount), 0) AS total
        FROM $_transactionsTable
        WHERE type = ? AND created_at >= ? AND created_at < ?
      ''', <Object>[
        DebtTransactionType.payment.databaseValue,
        start.toIso8601String(),
        end.toIso8601String(),
      ]);
      return DashboardSnapshot(
        totalOutstanding: (totalRows.first['total'] as num).toInt(),
        paymentsToday: (todayRows.first['total'] as num).toInt(),
      );
    });
  }

  Future<int> getTotalOutstandingDebt() async {
    final database = await _getDatabase();
    final rows = await database.rawQuery(
      'SELECT COALESCE(SUM(current_balance), 0) AS total '
      'FROM $_customersTable',
    );
    return (rows.first['total'] as num).toInt();
  }

  Future<bool> verifyCustomerLedger(int customerId) async {
    final database = await _getDatabase();
    return database.transaction((transaction) async {
      final customer = await _customerInTransaction(transaction, customerId);
      if (customer == null) return false;
      return _verifyLedgerInTransaction(transaction, customer);
    });
  }

  Future<Map<int, bool>> verifyAllCustomerLedgers() async {
    final database = await _getDatabase();
    return database.transaction((transaction) async {
      final rows = await transaction.query(_customersTable, orderBy: 'id ASC');
      final results = <int, bool>{};
      for (final row in rows) {
        final customer = Customer.fromMap(row);
        results[customer.id!] =
            await _verifyLedgerInTransaction(transaction, customer);
      }
      return results;
    });
  }

  Future<Customer?> _customerInTransaction(
    Transaction transaction,
    int customerId,
  ) async {
    final rows = await transaction.query(
      _customersTable,
      where: 'id = ?',
      whereArgs: <Object>[customerId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return Customer.fromMap(rows.first);
  }

  Future<bool> _verifyLedgerInTransaction(
    Transaction transaction,
    Customer customer,
  ) async {
    final rows = await transaction.query(
      _transactionsTable,
      where: 'customer_id = ?',
      whereArgs: <Object>[customer.id!],
      orderBy: 'id ASC',
    );

    var calculatedBalance = 0;
    var expectedPreviousHash = DebtTransaction.genesisHash;

    for (final row in rows) {
      DebtTransaction entry;
      try {
        entry = DebtTransaction.fromMap(row);
      } on FormatException {
        return false;
      } on TypeError {
        return false;
      }

      if (entry.previousHash != expectedPreviousHash || !entry.hasValidHash) {
        return false;
      }
      if (entry.type == DebtTransactionType.debt) {
        calculatedBalance += entry.amount;
      } else {
        calculatedBalance -= entry.amount;
      }
      if (calculatedBalance < 0) return false;
      expectedPreviousHash = entry.recordHash;
    }

    return calculatedBalance == customer.currentBalance;
  }

  Future<void> close() async {
    final pending = _openingDatabase;
    if (pending != null) await pending;
    final database = _database;
    _database = null;
    if (database != null && database.isOpen) await database.close();
  }
}
