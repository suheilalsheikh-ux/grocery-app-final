import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../models/debt_transaction.dart';
import '../services/ledger_service.dart';

/// Thermal-printer-style Arabic receipt; consumes a digitally signed receipt.
/// To share a PNG/PDF of this widget, wrap it in RepaintBoundary in the screen.
class ReceiptCard extends StatelessWidget {
  const ReceiptCard({
    super.key,
    required this.receipt,
  });

  final SignedLedgerReceipt receipt;

  static const Color _ink = Color(0xFF262626);
  static const Color _muted = Color(0xFF696969);
  static const Color _paper = Colors.white;

  String _money(int minorUnits) {
    final scale = receipt.unitsPerMajor;
    final major = minorUnits ~/ scale;
    final remaining = minorUnits % scale;
    final digits = scale == 1 ? 0 : scale.toString().length - 1;
    final majorText = NumberFormat.decimalPattern('ar').format(major);
    final value = digits == 0
        ? majorText
        : '$majorText.${remaining.toString().padLeft(digits, '0')}';
    return '$value ${receipt.currencySymbol}';
  }

  @override
  Widget build(BuildContext context) {
    final transaction = receipt.entry.transaction;
    final isPayment = transaction.type == DebtTransactionType.payment;
    final formattedDate = DateFormat('yyyy/MM/dd - hh:mm a', 'ar')
        .format(transaction.createdAt.toLocal());
    final items = transaction.purchases
        .split(RegExp(r'[+\n،]+'))
        .map((item) => item.trim())
        .where((item) => item.isNotEmpty)
        .toList(growable: false);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Container(
        width: 350,
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 24),
        decoration: BoxDecoration(
          color: _paper,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFFE6E6E6)),
          boxShadow: const [
            BoxShadow(
              color: Color(0x12000000),
              blurRadius: 20,
              offset: Offset(0, 6),
            ),
          ],
        ),
        child: DefaultTextStyle(
          style: const TextStyle(
            fontFamily: 'Roboto',
            color: _ink,
            fontSize: 13,
            height: 1.55,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Icon(
                Icons.storefront_outlined,
                color: _ink,
                size: 34,
              ),
              const SizedBox(height: 5),
              Text(
                receipt.shopName,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                ),
                textAlign: TextAlign.center,
              ),
              if (receipt.shopAddress != null &&
                  receipt.shopAddress!.isNotEmpty)
                Text(
                  receipt.shopAddress!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: _muted),
                ),
              if (receipt.shopPhone != null &&
                  receipt.shopPhone!.isNotEmpty)
                Text(
                  'هاتف: ${receipt.shopPhone}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: _muted),
                ),
              const SizedBox(height: 14),
              _dottedDivider(),
              const SizedBox(height: 12),
              Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: isPayment
                        ? const Color(0xFFEAF4ED)
                        : const Color(0xFFF2EEE6),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    isPayment ? 'سند قبض / سداد' : 'فاتورة دين',
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              _detailRow('رقم العملية', '#${transaction.id}'),
              _detailRow('التاريخ', formattedDate),
              _detailRow('اسم الزبون', receipt.customer.name),
              _detailRow('رقم الزبون', '${receipt.customer.id}'),
              const SizedBox(height: 10),
              _dottedDivider(),
              const SizedBox(height: 9),
              if (!isPayment) ...[
                const Text(
                  'الأصناف',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
                const SizedBox(height: 5),
                if (items.isEmpty)
                  Text(transaction.purchases)
                else
                  ...items.map(
                    (item) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('•  '),
                          Expanded(child: Text(item)),
                        ],
                      ),
                    ),
                  ),
                const SizedBox(height: 10),
              ],
              _dottedDivider(),
              const SizedBox(height: 10),
              _detailRow(
                isPayment ? 'المبلغ المقبوض' : 'قيمة المشتريات',
                _money(transaction.amount),
                prominent: true,
              ),
              const SizedBox(height: 6),
              Container(
                padding: const EdgeInsets.all(11),
                color: const Color(0xFFF5F5F5),
                child: _detailRow(
                  'إجمالي الدين المتبقي',
                  _money(receipt.entry.balanceAfter),
                  prominent: true,
                ),
              ),
              const SizedBox(height: 16),
              _dottedDivider(),
              const SizedBox(height: 12),
              const Text(
                'امسح الرمز للتحقق من بيانات العملية وتوقيع البقالة',
                textAlign: TextAlign.center,
                style: TextStyle(color: _muted, fontSize: 11),
              ),
              const SizedBox(height: 8),
              Center(
                child: QrImageView(
                  data: receipt.qrPayload,
                  version: QrVersions.auto,
                  errorCorrectionLevel: QrErrorCorrectLevel.M,
                  size: 270,
                  padding: const EdgeInsets.all(7),
                  backgroundColor: _paper,
                  semanticsLabel: 'رمز التحقق من صحة الإيصال',
                  errorStateBuilder: (context, error) => const SizedBox(
                    height: 90,
                    child: Center(
                      child: Text(
                        'تعذّر إنشاء رمز QR: بيانات الإيصال طويلة جداً',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 5),
              Text(
                'معرّف مفتاح البقالة: ${receipt.signingKeyFingerprint}',
                textAlign: TextAlign.center,
                style: const TextStyle(color: _muted, fontSize: 10),
              ),
              const SizedBox(height: 9),
              const Text(
                'شكراً لتعاملكم معنا',
                textAlign: TextAlign.center,
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
              const Text(
                'احتفظ بهذا الإيصال كمرجع للعملية',
                textAlign: TextAlign.center,
                style: TextStyle(color: _muted, fontSize: 11),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _detailRow(
    String title,
    String value, {
    bool prominent = false,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: prominent ? 14 : 12,
              fontWeight: prominent ? FontWeight.w700 : FontWeight.normal,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.left,
              style: TextStyle(
                fontWeight: prominent ? FontWeight.w800 : FontWeight.w500,
                fontSize: prominent ? 15 : 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _dottedDivider() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final count = (constraints.maxWidth / 10).floor();
        return Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List<Widget>.generate(
            count,
            (_) => const SizedBox(
              width: 5,
              child: Divider(
                thickness: 1,
                color: Color(0xFFBBBBBB),
              ),
            ),
          ),
        );
      },
    );
  }
}
