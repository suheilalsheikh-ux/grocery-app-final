import 'package:flutter/material.dart';

import '../services/notification_service.dart';

/// Render overdue customers and offer one-tap WhatsApp, SMS composer,
/// and optionally direct SMS (only when legally/policy permitted).
class OverdueRemindersList extends StatefulWidget {
  const OverdueRemindersList({
    super.key,
    required this.shopName,
    this.notificationService,
    this.daysOverdue = 30,
    this.directSmsEnabled = false,
  });

  final String shopName;
  final NotificationService? notificationService;
  final int daysOverdue;
  final bool directSmsEnabled;

  @override
  State<OverdueRemindersList> createState() => _OverdueRemindersListState();
}

class _OverdueRemindersListState extends State<OverdueRemindersList> {
  late final NotificationService _service;
  late Future<List<OverdueDebt>> _future;
  int? _busyCustomerId;
  final Set<int> _smsSentThisSession = <int>{};

  @override
  void initState() {
    super.initState();
    _service = widget.notificationService ?? NotificationService();
    _refresh();
  }

  void _refresh() {
    _future = _service.getOverdueDebts(daysOverdue: widget.daysOverdue);
  }

  Future<void> _run(
    OverdueDebt overdue,
    Future<void> Function() operation, {
    bool markSmsSent = false,
  }) async {
    if (_busyCustomerId != null) return;
    setState(() => _busyCustomerId = overdue.customer.id);
    try {
      await operation();
      if (markSmsSent) _smsSentThisSession.add(overdue.customer.id!);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(markSmsSent
              ? 'أكد أندرويد إرسال أجزاء SMS إلى الشبكة (وليس الاستلام).'
              : 'تم فتح تطبيق الإرسال. اضغط إرسال من داخله.'),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذرت العملية: $error')),
      );
    } finally {
      if (mounted) setState(() => _busyCustomerId = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            children: <Widget>[
              const Expanded(
                child: Text(
                  'تذكيرات الديون المتأخرة',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              IconButton(
                tooltip: 'تحديث القائمة',
                icon: const Icon(Icons.refresh),
                onPressed: () => setState(_refresh),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text(
              'ديون مضى عليها أكثر من ${widget.daysOverdue} يوماً '
              'مع احتساب السداد للأقدم أولاً.',
            ),
          ),
          FutureBuilder<List<OverdueDebt>>(
            future: _future,
            builder: (context, snapshot) {
              if (snapshot.connectionState != ConnectionState.done) {
                return const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(child: CircularProgressIndicator()),
                );
              }
              if (snapshot.hasError) {
                return Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text('تعذر تحميل المتأخرات: ${snapshot.error}'),
                );
              }
              final overdueList = snapshot.data ?? <OverdueDebt>[];
              if (overdueList.isEmpty) {
                return const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(child: Text('لا توجد ديون متأخرة حالياً.')),
                );
              }
              return ListView.builder(
                itemCount: overdueList.length,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemBuilder: (context, index) {
                  final item = overdueList[index];
                  final busy = _busyCustomerId == item.customer.id;
                  final canPress = _busyCustomerId == null;
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 5),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(item.customer.name,
                              style: Theme.of(context).textTheme.titleMedium),
                          const SizedBox(height: 4),
                          Text('الهاتف: ${item.customer.phone}'),
                          Text('المتأخر: ${NotificationService.money(item.overdueAmount)} ريال'),
                          Text('إجمالي الرصيد: '
                              '${NotificationService.money(item.totalOutstanding)} ريال'),
                          Text('عمر أقدم مبلغ غير مسدد: ${item.overdueDays} يوماً'),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: <Widget>[
                              FilledButton.icon(
                                onPressed: !canPress ? null : () => _run(
                                  item,
                                  () => _service.openWhatsAppReminder(
                                    overdue: item,
                                    shopName: widget.shopName,
                                  ),
                                ),
                                icon: const Icon(Icons.chat_outlined),
                                label: const Text('فتح واتساب'),
                              ),
                              OutlinedButton.icon(
                                onPressed: !canPress ? null : () => _run(
                                  item,
                                  () => _service.openSmsReminderComposer(
                                    overdue: item,
                                    shopName: widget.shopName,
                                  ),
                                ),
                                icon: const Icon(Icons.sms_outlined),
                                label: const Text('رسالة SMS'),
                              ),
                              if (widget.directSmsEnabled)
                                OutlinedButton.icon(
                                  onPressed: !canPress ||
                                          _smsSentThisSession.contains(item.customer.id)
                                      ? null
                                      : () => _run(
                                          item,
                                          () async {
                                            await _service.sendSmsReminder(
                                              overdue: item,
                                              shopName: widget.shopName,
                                              smsEnabledByShopkeeper: true,
                                            );
                                          },
                                          markSmsSent: true,
                                        ),
                                  icon: const Icon(Icons.send_outlined),
                                  label: Text(busy ? 'جارٍ الإرسال...' : 'إرسال SMS مباشر'),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }
}
