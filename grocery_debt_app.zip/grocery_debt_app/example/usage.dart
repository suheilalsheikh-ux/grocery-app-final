import 'package:smart_grocery_debt/models/customer.dart';
import 'package:smart_grocery_debt/services/database_helper.dart';
import 'package:smart_grocery_debt/services/ledger_service.dart';
import 'package:smart_grocery_debt/services/receipt_signing_service.dart';
import 'package:smart_grocery_debt/widgets/receipt_card.dart';

/// Call this only on a button press in your app (not on each widget rebuild).
Future<ReceiptCard> createFirstDemoReceipt() async {
  final database = DatabaseHelper.instance;
  final ledger = LedgerService();

  final customer = await database.createCustomer(
    const Customer(
      name: 'أحمد محمد',
      phone: '777123456',
      creditLimit: 50000,
    ),
  );

  final receipt = await ledger.addDebtWithReceipt(
    customerId: customer.id!,
    amount: 1500,
    items: 'زبادي + خبز',
    shopName: 'بقالة البركة',
    shopPhone: '777123000',
    shopAddress: 'صنعاء - اليمن',
  );

  final statement = await ledger.getStatement(customer.id!);
  assert(statement.remainingBalance == 1500);

  // Obtain the public key independently from the merchant's secure app.
  final trustedMerchantKey =
      await ReceiptSigningService.instance.getPublicKeyBase64();
  final qrIsValid = await ReceiptSigningService.verifyQrPayload(
    qrPayload: receipt.qrPayload,
    trustedPublicKeyBase64: trustedMerchantKey,
  );
  assert(qrIsValid);

  return ReceiptCard(receipt: receipt);
}

Future<ReceiptCard> createPaymentReceipt({
  required int customerId,
}) async {
  final ledger = LedgerService();
  final paymentReceipt = await ledger.registerPaymentWithReceipt(
    customerId: customerId,
    amount: 500,
    shopName: 'بقالة البركة',
  );
  return ReceiptCard(receipt: paymentReceipt);
}
