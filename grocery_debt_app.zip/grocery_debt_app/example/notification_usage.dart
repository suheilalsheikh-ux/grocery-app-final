import 'package:flutter/material.dart';
import 'package:smart_grocery_debt/services/ledger_service.dart';
import 'package:smart_grocery_debt/services/notification_service.dart';
import 'package:smart_grocery_debt/widgets/overdue_reminders_list.dart';

const shopName = 'بقالة البركة';

/// Call only after the shopkeeper has enabled automatic SMS in settings.
/// SAVE FIRST; on SMS error never repeat addDebt to try sending again.
Future<void> addDebtAndNotify({
  required int customerId,
  required int amount,
  required String items,
  required bool smsOptedIn,
}) async {
  final notifications = NotificationService(ledger: LedgerService());
  final outcome = await notifications.recordDebtAndNotify(
    customerId: customerId,
    amount: amount,
    items: items,
    shopName: shopName,
    smsEnabledByShopkeeper: smsOptedIn,
  );
  if (outcome.smsError != null) {
    // The debt is already saved; show a warning without creating it again.
    debugPrint('تم حفظ الدين، لكن تعذر إرسال SMS: ${outcome.smsError}');
  }
}

/// Embed this widget inside a SingleChildScrollView for a reminders screen.
Widget buildRemindersScreen() {
  return const Scaffold(
    body: SafeArea(
      child: SingleChildScrollView(
        padding: EdgeInsets.all(12),
        child: OverdueRemindersList(
          shopName: shopName,
          daysOverdue: 30,
          directSmsEnabled: false, // Play-compliant default: composer / WA.
        ),
      ),
    ),
  );
}
