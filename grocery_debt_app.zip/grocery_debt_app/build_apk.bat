@echo off
cd /d "%~dp0"
python tools\prepare_android.py || exit /b 1
call flutter pub get || exit /b 1
call flutter analyze || exit /b 1
call flutter test || exit /b 1
call flutter build apk --release || exit /b 1
echo APK: build\app\outputs\flutter-apk\app-release.apk
